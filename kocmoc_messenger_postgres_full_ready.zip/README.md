# 💬 kocmoc Messenger

Современный веб-мессенджер с SQLite базой данных и REST API.

## 🚀 Быстрый старт

### 1. Установка

```bash
# Клонируйте репозиторий или распакуйте архив
cd kocmoc-messenger

# Установите зависимости
npm install
```

### 2. Конфигурация

Создайте файл `.env` в корне проекта:

```env
PORT=3000
JWT_SECRET=your-secret-key-here
NODE_ENV=development
```

### 3. Запуск

```bash
# Обычный запуск
npm start

# Для разработки (с автоперезагрузкой)
npm run dev
```

Откройте браузер: **http://localhost:3000**

## 📦 Структура проекта

```
kocmoc-messenger/
├── server/
│   ├── server.js          # Главный файл
│   ├── database.js        # Работа с SQLite
│   ├── routes/            # API роуты
│   │   ├── auth.js
│   │   ├── users.js
│   │   ├── chats.js
│   │   └── messages.js
│   └── middleware/
│       └── auth.js        # JWT авторизация
├── public/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── app.js
│       ├── auth.js
│       ├── chat.js
│       └── admin.js
├── database/
│   └── kocmoc.db           # SQLite БД (создаётся автоматически)
├── package.json
├── .env
└── README.md
```

## 🔑 Админ доступ по умолчанию

```
Email: admin@kocmoc.ru
Password: adminkocmocmesanger123456789hi
```

**⚠️ ВАЖНО:** Измените пароль после первого входа!

## 🛠 API Endpoints

### Авторизация

```
POST   /api/auth/register     # Регистрация
POST   /api/auth/login        # Вход
POST   /api/auth/logout       # Выход
GET    /api/auth/verify       # Проверка токена
GET    /api/auth/accounts/:deviceId  # Аккаунты на устройстве
```

### Пользователи

```
GET    /api/users            # Все пользователи
GET    /api/users/:id        # Профиль пользователя
PUT    /api/users/:id        # Обновить профиль
PUT    /api/users/:id/password  # Изменить пароль
PUT    /api/users/:id/ban    # Заблокировать (админ)
PUT    /api/users/:id/unban  # Разблокировать (админ)
DELETE /api/users/:id        # Удалить (админ)
```

### Чаты

```
GET    /api/chats            # Все чаты пользователя
POST   /api/chats            # Создать чат
GET    /api/chats/:id        # Данные чата
PUT    /api/chats/:id        # Обновить настройки
DELETE /api/chats/:id        # Удалить чат
```

### Сообщения

```
GET    /api/messages/:chatId        # Сообщения чата
POST   /api/messages/:chatId        # Отправить сообщение
PUT    /api/messages/:chatId/read   # Пометить прочитанными
DELETE /api/messages/:id            # Удалить сообщение
```

### Админ

```
GET    /api/users/admin/stats      # Статистика
GET    /api/users/admin/devices    # Устройства
PUT    /api/users/admin/devices/:id/reset  # Сброс счётчика
```

## 🔐 Авторизация

Используйте JWT токен в заголовке:

```javascript
headers: {
  'Authorization': 'Bearer YOUR_TOKEN_HERE'
}
```

## 💾 База данных

- **Тип:** SQLite3 (файловая)
- **Расположение:** `database/kocmoc.db`
- **Кроссплатформенность:** Windows, Linux, macOS
- **Автоматическое создание:** При первом запуске

### Таблицы

- `users` - Пользователи
- `chats` - Чаты
- `chat_participants` - Участники чатов
- `messages` - Сообщения
- `devices` - Устройства
- `sessions` - Сессии пользователей

## ⚙️ Функционал

### Пользователи

- ✅ Регистрация и авторизация
- ✅ JWT токены
- ✅ Хеширование паролей (bcrypt)
- ✅ Лимит 3 аккаунта на устройство
- ✅ Множественные аккаунты (переключение)
- ✅ Редактирование профиля
- ✅ Загрузка аватара (URL)

### Чаты

- ✅ Личные чаты (1-на-1)
- ✅ Групповые чаты
- ✅ Список чатов с последним сообщением
- ✅ Счётчик непрочитанных
- ✅ Отключение звука
- ✅ Архивирование

### Сообщения

- ✅ Отправка текстовых сообщений
- ✅ История сообщений
- ✅ Статус доставки
- ✅ Удаление сообщений
- ✅ Пагинация

### Админ-панель

- ✅ Статистика системы
- ✅ Управление пользователями
- ✅ Блокировка аккаунтов
- ✅ Просмотр всех сообщений
- ✅ Управление устройствами
- ✅ Удаление пользователей

## 🔧 Зависимости

```json
{
  "express": "^4.18.2",       // Веб-сервер
  "sqlite3": "^5.1.6",        // База данных
  "bcrypt": "^5.1.1",         // Хеширование
  "jsonwebtoken": "^9.0.2",   // JWT токены
  "cors": "^2.8.5",           // CORS
  "body-parser": "^1.20.2",   // Парсинг JSON
  "dotenv": "^16.3.1"         // Переменные окружения
}
```

## 🐛 Решение проблем

### База данных не создаётся

```bash
# Убедитесь что папка database существует
mkdir database

# Проверьте права доступа (Linux/Mac)
chmod 755 database
```

### Ошибка при установке sqlite3 (Windows)

```bash
# Установите windows-build-tools
npm install --global windows-build-tools

# Переустановите sqlite3
npm install sqlite3 --build-from-source
```

### Порт 3000 занят

Измените порт в файле `.env`:
```
PORT=8080
```

## 📝 Разработка

### Добавление новых роутов

1. Создайте файл в `server/routes/`
2. Добавьте роуты с использованием `authenticateToken`
3. Подключите в `server/server.js`

### Изменение схемы БД

Отредактируйте `server/database.js` функцию `initDatabase()`

### Миграции

Для изменения существующей БД:

```javascript
db.run('ALTER TABLE users ADD COLUMN new_field TEXT');
```

## 🚀 Деплой

### На VPS (Ubuntu/Debian)

```bash
# Установите Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Установите PM2
npm install -g pm2

# Запустите приложение
pm2 start server/server.js --name kocmoc-messenger
pm2 save
pm2 startup
```

### Nginx (прокси)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📄 Лицензия

MIT

## 👨‍💻 Автор

kocmoc Messenger Team

---

**Примечание:** Это учебный проект. Для продакшена добавьте:
- HTTPS
- Rate limiting
- Валидацию входных данных
- Логирование
- Резервное копирование БД
- WebSocket для real-time обновлений