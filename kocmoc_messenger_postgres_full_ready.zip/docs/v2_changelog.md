v2: maintenance mode, admin button, color tweaks, SSL, http2
